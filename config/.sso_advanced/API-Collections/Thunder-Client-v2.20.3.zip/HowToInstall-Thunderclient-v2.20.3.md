How to install old version of Thunder Client in VS Code:
1. Install latest version of Thunder Client from VS Code Extension Marketplace
2. Access VS Code extensions folder (e.g., by clicking on "Size" on the info page for any installed extension). For example: C:\Users\Karsten\.vscode\extensions\
3. Close VS Code
4. Extract rangav.vscode-thunder-client-2.20.3.zip to this folder -> C:\Users\Karsten\.vscode\extensions\rangav.vscode-thunder-client-2.20.3
5. Edit extensions.json in this the extensions folder and replace the JSON object of the latest Thunder Client version with the content of the extensions.json from here, except the [] (or replace the whole file if there are no other extensions)
6. Remove the folder of the latest Thunder Client version
7. Start VS Code and check which version of Thunder Client is now installed